#ifndef CAPTDNS_H
#define CAPTDNS_H
void   captdnsInit(void);

#endif
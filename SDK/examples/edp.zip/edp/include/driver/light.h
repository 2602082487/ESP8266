#ifndef _LIGHT_H
#define _LIGHT_H

void bh1750_init();
uint16 bh1750_GetLightValue();



#endif
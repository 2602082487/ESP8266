#include "esp_common.h"
#include "driver/i2c_master.h"
#include "driver/light.h"
#include "EdpKit.h"
#include "lwip/sockets.h"


/*********************varible define*************************/
int s;
//char ssid[]="LieBaoWiFi625";
//char password[]="12345613";
char ssid[]="CMCC-g75h";
char password[]="su4fbhy9";
char buffer[512];




/************************************************************/

void send_task()
{
	EdpPacket *pkg;
	struct sockaddr_in remote_ip;
	remote_ip.sin_family = AF_INET;
	remote_ip.sin_addr.s_addr = inet_addr(SERVER_IP);
	remote_ip.sin_port = htons(SERVER_PORT);
	xSemaphoreTake(wifi_sta,0);
	vTaskDelay(1000);
	s=socket(AF_INET,SOCK_STREAM,0);
	if(connect(s,(struct sockaddr *)(&remote_ip), sizeof(struct sockaddr))!=0)
		os_printf("\r\nsocket connect errro\r\n");
	xTaskCreate(recv_task,"recv_task",200,NULL,7,&Handle_recv_task);
	xTaskCreate(ping_task,"ping_task",200,NULL,2,&Handle_ping_task);
	while(1)
	{
		if(xQueueReceive(send_queue,&pkg,0)==pdTRUE)
		{
			int i;
			send(s,pkg->_data,pkg->_write_pos,0);
			os_printf("\r\nESP8266@GOD:socket send ping\r\n");
			for(i=0;i<pkg->_write_pos;i++)
				os_printf(" %X",(pkg->_data)[i]);
			DeleteBuffer(&pkg);
		}
		else
			os_printf("\r\nESP8266@GOD:receive fail\r\n");
		vTaskDelay(20);
	}
}


void light_task()
{
	uint16 light_value;
	char str_value[30];
	EdpPacket *pkg;
	bh1750_init();
#ifdef DEBUG_PRINT
	os_printf("\r\nESP8266@GOD:bh1750 init finish\r\n");
#endif
	while(1)
	{
		light_value=bh1750_GetLightValue();
#ifdef DEBUG_PRINT
		os_printf("\r\nESP8266@GOD:light value:%d\r\n",light_value);
#endif
		sprintf(str_value,",;light,%d",light_value);
		pkg=PacketSavedataSimpleString(device_id, str_value);
		xQueueSend(send_queue,&pkg,0);
		vTaskDelay(5000);
	}
}


void ping_task()
{
	EdpPacket *pkg;
	pkg=PacketConnect1(device_id,api_key);
	if(xQueueSend(send_queue,&pkg,5)==pdTRUE)
		os_printf("\r\nESP8266@GOD:Queue send ok!\r\n");
	else
		os_printf("\r\nESP8266@GOD:Queue send fail!\r\n");
	vTaskDelay(20);
	xTaskCreate(light_task,"light_task",200,NULL,6,&Handle_light_task);
	while(1)
	{	
		pkg=PacketPing();
		os_printf("\r\nping task erter\r\n");
		if(xQueueSend(send_queue,&pkg,0)==pdTRUE)
			os_printf("\r\nESP8266@GOD:Queue send ok!\r\n");
		else
			os_printf("\r\nESP8266@GOD:Queue send fail!\r\n");
		vTaskDelay(5000);
	}
}


void recv_task()
{
	int i,n;
	uint8 mtype;
	RecvBuffer* recv_buf = NewBuffer();
	EdpPacket *pkg;
	char* cmdid;
    uint16 cmdid_len;
    char*  cmd_req;
    uint32 cmd_req_len;
	while(1)
	{
		n=recv(s,buffer,512,MSG_DONTWAIT);
		if(n>0)
		{
			printf("ESP8266@GOD:recived data:\r\n");
#ifdef DEBUG_PRINT
			for(i=0;i<n;i++)
			{
				printf("%X ",buffer[i]);
			}
			printf("\r\n");
#endif
		WriteBytes(recv_buf, buffer, n);
		if((pkg=GetEdpPacket(recv_buf))!=0)
		{
			mtype=EdpPacketType(pkg);
			switch(mtype)
			{
				case CONNRESP:
					os_printf("\r\nCONNRESP\r\n");
					break;
				case PUSHDATA:
					os_printf("\r\nPUSHDATA\r\n");
					break;
				case SAVEDATA:
					os_printf("\r\nSAVEDATA\r\n");
					break;
				case SAVEACK:
					os_printf("\r\nSAVEDATA\r\n");
					break;
				case CMDREQ:
					os_printf("\r\nCMDREQ\r\n");
					break;
				case PINGRESP:
					os_printf("\r\nPINGRESP\r\n");
				default:
					os_printf("\r\ndefault:recv failde!\r\n");
			}
			DeleteBuffer(&pkg);
		}
		}
		vTaskDelay(10);
	}
}


void network_task()
{
	struct station_config * config = (struct station_config *)zalloc(sizeof(struct station_config));
	sprintf(config->ssid,ssid);
	sprintf(config->password, password);
	config->bssid_set=0;
	wifi_set_opmode(STATION_MODE);
	wifi_station_set_config(config);
	while(1)
	{
		switch(wifi_station_get_connect_status ())
		{
			case STATION_GOT_IP:
				printf("ESP8266@GOD:Get ip\r\n");
				xSemaphoreGive(wifi_sta);
				vTaskSuspend(Handle_network_task);
				break;
			case STATION_CONNECT_FAIL:
				printf("ESP8266@GOD:Connect failed\r\n");
				break;
			case STATION_WRONG_PASSWORD:
				printf("ESP8266@GOD:Password:%s is wrong\r\n",password);
				break;
			case STATION_NO_AP_FOUND:
				printf("ESP8266@GOD:Not find %s\r\n",ssid);
				break;
			case STATION_CONNECTING:
				printf("ESP8266@GOD:Connecting now\r\n");
				break;
			case STATION_IDLE:
				printf("ESP8266@GOD:WiFi idle\r\n");
				break;
			default:
				break;
		}
		vTaskDelay(100);
	}
}





